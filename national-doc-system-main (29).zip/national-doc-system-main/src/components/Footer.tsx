const Footer = () => {
  return (
    <footer className="mt-auto py-6 text-center">
      <p className="text-sm text-muted-foreground font-bold">© ٢٠٢٥ حكومة قطر</p>
    </footer>
  );
};

export default Footer;
